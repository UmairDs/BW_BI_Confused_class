import streamlit as st
import pandas as pd

# Page settings
st.set_page_config(
    page_title="GPA Calculator",
    page_icon="🎓",
    layout="centered"
)

# Title
st.title("🎓 GPA Calculator")
st.write("Enter your course details to calculate your GPA.")

# Number of courses
courses = st.number_input(
    "Enter number of courses:",
    min_value=1,
    max_value=20,
    value=1,
    step=1
)

st.markdown("---")

# Create empty list
data = []

# Taking input for each course
for i in range(courses):

    st.subheader(f"Course {i + 1}")

    col1, col2 = st.columns(2)

    with col1:

        course_name = st.text_input(
            "Course name",
            key=f"name_{i}"
        )

        credit_hours = st.number_input(
            "Credit hours",
            min_value=0.0,
            value=3.0,
            step=0.5,
            key=f"credit_{i}"
        )

    with col2:

        obtained_marks = st.number_input(
            "Obtained marks",
            min_value=0.0,
            value=0.0,
            step=1.0,
            key=f"obtained_{i}"
        )

        total_marks = st.number_input(
            "Total marks",
            min_value=1.0,
            value=100.0,
            step=1.0,
            key=f"total_{i}"
        )

    # Store course data
    data.append([
        course_name if course_name else f"Course {i + 1}",
        credit_hours,
        obtained_marks,
        total_marks
    ])

    st.markdown("---")


# Calculate button
if st.button("🧮 Calculate GPA", type="primary"):

    total_points = 0
    total_credits = 0

    results = []

    # Calculate each course
    for course in data:

        course_name = course[0]
        credit_hours = course[1]
        obtained_marks = course[2]
        total_marks = course[3]

        # Check marks
        if obtained_marks > total_marks:

            st.error(
                f"Obtained marks for {course_name} "
                f"cannot be greater than total marks."
            )

            st.stop()

        # Calculate percentage
        percentage = (obtained_marks / total_marks) * 100

        # Calculate grade
        if percentage >= 90:
            grade_point = 4.0
            grade = "A"

        elif percentage >= 85:
            grade_point = 4.0
            grade = "A-"

        elif percentage >= 80:
            grade_point = 3.3
            grade = "B+"

        elif percentage >= 75:
            grade_point = 3.0
            grade = "B"

        elif percentage >= 70:
            grade_point = 2.7
            grade = "B-"

        elif percentage >= 65:
            grade_point = 2.3
            grade = "C+"

        elif percentage >= 60:
            grade_point = 2.0
            grade = "C"

        elif percentage >= 55:
            grade_point = 1.0
            grade = "D"

        else:
            grade_point = 0.0
            grade = "F"

        # Quality points
        points = credit_hours * grade_point

        # Add totals
        total_points += points
        total_credits += credit_hours

        # Store results
        results.append({
            "Course": course_name,
            "Credit Hours": credit_hours,
            "Obtained": obtained_marks,
            "Total": total_marks,
            "Percentage": round(percentage, 2),
            "Grade": grade,
            "Grade Point": grade_point
        })

    # Display results
    st.subheader("📊 Results")

    df = pd.DataFrame(results)

    st.dataframe(
        df,
        use_container_width=True,
        hide_index=True
    )

    # Calculate GPA
    if total_credits > 0:

        gpa = total_points / total_credits

        st.success(
            f"🎓 Your Final GPA is: {gpa:.2f}"
        )

        st.info(
            f"Total Credit Hours: {total_credits:.1f}"
        )

    else:

        st.warning(
            "No credit hours were entered."
        )